import java.util.*;

public class Mansion {

    private ArrayList<String> hallway;
    private ArrayList<Room> rooms;


    public Mansion(){
        hallway = new ArrayList<String>();
        rooms = new ArrayList<Room>();
        createHallRooms();

    }

    private void createHallRooms(){
        //This adds and creates the rooms that you can select, 1-8 at indexes 0-7, respectively.
        boolean cluesAssigned = false;


        int clue1 = (int) (Math.random()*8)+1;
        int clue2 = (int) (Math.random()*8)+1;
        while (clue1 == clue2){
            clue2 = (int) (Math.random()*8)+1;
        }
        int clue3 = (int) (Math.random()*8)+1;
        while (clue3 == clue1 || clue3 == clue2){
            clue3 = (int) (Math.random()*8)+1;
        }
        int clue4 = (int) (Math.random()*8)+1;
        while (clue4 == clue1 || clue4 == clue2 || clue4 == clue3){
            clue4 = (int) (Math.random()*8)+1;
        }

        //generates indexes that will be divided into room difficulties after this
        int [] difficultyNums = {0, 1, 2, 3, 4, 5, 6, 7};
        for (int currentIndex=0; currentIndex < difficultyNums.length; currentIndex++){
            int newIndex = (int) (Math.random()*8);
            int currentNum = difficultyNums[currentIndex];
            int swapNum = difficultyNums[newIndex];
            difficultyNums[currentIndex] = swapNum;
            difficultyNums[newIndex] = currentNum;
        }



        //FOR TESTING
        /*for (int i=0; i<difficultyNums.length; i++){
            System.out.print(difficultyNums[i]+" ");
        }
        System.out.println();*/


        //we have 4 ints, clue1, clue2, clue3, and clue4, all of which
        // are a room number that will have a clue in it. The other rooms will
        // have false clues


        //creates numbers of rooms in hallway ArrayList and blank 7x7 rooms in rooms ArrayList
        for (int i=1; i<=8; i++){
            hallway.add(i+"");
            rooms.add(new Room(7));
        }

        //uses generated difficulties to create traps for each room
        for (int i=0; i<difficultyNums.length; i++) {
            if (i <= 2) {
                rooms.get(difficultyNums[i]).createTraps(0);
            } else if (i <= 5) {
                rooms.get(difficultyNums[i]).createTraps(1);
            } else{
                rooms.get(difficultyNums[i]).createTraps(2);
            }
        }


        // generates reward cells for each room
        for (Room room : rooms){
            room.createReward();
        }


        //FOR TESTING
        markIsCompleted(2); 
    }

    //Room object accessor
    public Room getRoom(int roomNum){
        return rooms.get(roomNum-1);
    }

    //hallway ArrayList accessor
    public ArrayList<String> getHallway(){return hallway;}

    //this makes sure the Room that Vid is trying to enter is between 1-8 and not completed
    public boolean validateRC(String rc){
        int roomNum;
        try{
                roomNum = Integer.parseInt(rc);
            if (roomNum >= 1 && roomNum <= 8 && !(rooms.get(roomNum-1).getIsCompleted())){
                return true;
            }
        }
        catch(Exception e){
            return false;
        }
        return false;
    }

    //when a Room is completed, it becomes marked on the String ArrayList
    public void markIsCompleted(int roomNum){
        rooms.get(roomNum-1).changeIsCompleted();
        hallway.set(roomNum-1, "*");
    }

}



