import java.util.Scanner;

//this is the main testing/playing class- it essentially acts only to start
// the game and let us test individual components
public class mainGameTester {
    // hi :D
    //hallo :P
    //dean was here
    //大家好！
    //石头纸剪刀很糟糕
    //hi chloe
    //hello0o0o0o0o0o0o0o0o0o0o0o0o0o0o0o0o0o0o0o0o0o0o0o0o0o0

    public static void main(String [] args) {

        //this is for testing!
//        System.out.println("HEY Vid, welcome to the Linda pit. I challenge you to a game of Rock, Paper, Scissors. " +
//                "Choose wisely--your life depends on it.");
        //RPS.RPS();

        Game g = new Game();
        g.begin();

    }

}